export async function renderSheets(pdf,job,{document,container,createUrl=URL.createObjectURL,onProgress=()=>{}}){
 const urls=[];
 // Render each unique sheet once; its second copy reuses the same 300-dpi image.
 for(let i=1;i<=job.sheetsPerCopy;i++){
  onProgress(i,job.sheetsPerCopy);
  const page=await pdf.getPage(i);const viewport=page.getViewport({scale:300/72});
  const canvas=document.createElement('canvas');canvas.width=Math.ceil(viewport.width);canvas.height=Math.ceil(viewport.height);
  await page.render({canvasContext:canvas.getContext('2d'),viewport,background:'rgb(255,255,255)'}).promise;
  const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('No se pudo preparar la imagen de impresión.')),'image/png'));
  urls.push(createUrl(blob));canvas.width=canvas.height=0;page.cleanup();
 }
 for(let copy=0;copy<2;copy++)for(const url of urls){
  const sheet=document.createElement('section');sheet.className='sheet';
  const img=document.createElement('img');img.alt='Hoja del test';img.src=url;sheet.append(img);container.append(sheet);
  await img.decode();
 }
 return urls;
}
