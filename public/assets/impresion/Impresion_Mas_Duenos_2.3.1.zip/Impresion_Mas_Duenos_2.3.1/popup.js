'use strict';
const currentBtn = document.getElementById('currentTab');
const openBtn = document.getElementById('openPanel');
const hint = document.getElementById('tabHint');

async function openWorkbench(capture) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const params = new URLSearchParams();
  if (tab?.id && capture) {
    params.set('tab', String(tab.id));
    params.set('auto', '1');
  }
  await chrome.tabs.create({ url: chrome.runtime.getURL('panel.html') + (params.size ? '?' + params : '') });
  window.close();
}

currentBtn.addEventListener('click', () => openWorkbench(true).catch(err => { hint.textContent = String(err.message || err); }));
openBtn.addEventListener('click', () => openWorkbench(false).catch(err => { hint.textContent = String(err.message || err); }));
