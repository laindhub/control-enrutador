import { imposeTwoUpTwice } from './imposition.mjs';

const $ = (id) => document.getElementById(id);
const qs = new URLSearchParams(location.search);
let targetTabId = Number(qs.get('tab')) || null;
let pdfOutputUrl = null;
let pdfOutputName = 'impresion-2x2.pdf';
let busy = false;
let lastTab = null;
const autoLiniers = qs.get('liniers') === '1';
let autoOpened = false;

function safeFilename(name) {
  return String(name || 'documento').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '-').replace(/\.pdf$/i, '').slice(0, 70).trim() || 'documento';
}
function setNotice(message, type = 'normal') {
  const elem = $('progress');
  elem.hidden = false;
  elem.className = 'notice ' + (type === 'error' ? 'error' : type === 'good' ? 'good' : '');
  elem.textContent = message;
}
function setBusy(on) {
  busy = on;
  $('captureButton').disabled = on;
  $('pdfInput').disabled = on;
  $('dropZone').classList.toggle('is-busy', on);
}
function toByteArray(base64) {
  const raw = atob(base64);
  const bytes = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i += 1) bytes[i] = raw.charCodeAt(i);
  return bytes;
}
function isPdf(bytes) {
  return bytes.length >= 5 && String.fromCharCode(...bytes.slice(0, 5)) === '%PDF-';
}
async function readRemotePdf(url) {
  const parsed = new URL(url);
  if (!['https:', 'http:'].includes(parsed.protocol)) throw new Error('Este tipo de URL no permite descarga directa del PDF. Seleccioná el archivo desde tu equipo.');
  const response = await fetch(parsed.href, { credentials: 'include', redirect: 'follow', cache: 'no-store' });
  if (!response.ok) throw new Error('La página respondió HTTP ' + response.status);
  const limit = 70 * 1024 * 1024;
  const advertisedSize = Number(response.headers.get('content-length'));
  if (advertisedSize > limit) throw new Error('El PDF supera 70 MB. Guardalo en tu equipo y cargalo manualmente.');
  const data = new Uint8Array(await response.arrayBuffer());
  if (data.byteLength > limit) throw new Error('El archivo es demasiado grande (>70 MB).');
  if (!isPdf(data)) throw new Error('La dirección no devolvió un PDF (puede requerir autenticación especial).');
  return data;
}
async function captureWebpageAsPdf(tabId) {
  const target = { tabId };
  let attached = false;
  const layoutStyleId = 'laind-print-layout-' + crypto.randomUUID();
  let layoutStyleAdded = false;
  try {
    await chrome.debugger.attach(target, '1.3');
    attached = true;
    const adjusted = await chrome.scripting.executeScript({target,func:(id) => {
      if (!document.querySelector('.report-container')) return false;
      const style = document.createElement('style');
      style.id = id;
      style.textContent = '@media print { .report-container .section-title { break-after: avoid-page !important; page-break-after: avoid !important; } }';
      document.head.append(style);
      return true;
    },args:[layoutStyleId]});
    layoutStyleAdded = !!adjusted[0]?.result;
    const result = await chrome.debugger.sendCommand(target, 'Page.printToPDF', {
      landscape: false,
      displayHeaderFooter: false,
      printBackground: true,
      preferCSSPageSize: false,
      paperWidth: 8.2677,
      paperHeight: 11.6929,
      marginTop: 0.25,
      marginBottom: 0.25,
      marginLeft: 0.25,
      marginRight: 0.25,
      transferMode: 'ReturnAsBase64'
    });
    if (!result?.data) throw new Error('Edge no devolvió un documento.');
    return toByteArray(result.data);
  } finally {
    if (layoutStyleAdded) {
      try { await chrome.scripting.executeScript({target,func:(id) => document.getElementById(id)?.remove(),args:[layoutStyleId]}); } catch (_) { /* tab closed */ }
    }
    if (attached) {
      try { await chrome.debugger.detach(target); } catch (ignored) { /* already detached */ }
    }
  }
}
async function prepare(data, sourceName) {
  if (busy) return;
  setBusy(true);
  $('readySection').hidden = true;
  try {
    if (!globalThis.PDFLib?.PDFDocument) throw new Error('No se encontró la biblioteca PDF incluida. Volvé a extraer el ZIP completo y recargá la extensión.');
    if (!isPdf(data)) throw new Error('El archivo no tiene formato PDF válido.');
    const result = await imposeTwoUpTwice(data, msg => setNotice(msg));
    if (pdfOutputUrl) URL.revokeObjectURL(pdfOutputUrl);
    pdfOutputUrl = URL.createObjectURL(new Blob([result.bytes], { type: 'application/pdf' }));
    pdfOutputName = safeFilename(sourceName) + '-IMPRESION-2x2.pdf';
    $('resultTitle').textContent = pdfOutputName;
    $('resultCount').textContent = `${result.originalPages} páginas originales · ${result.sheetsPerCopy} hoja(s) por copia · ${result.totalSheets} hojas totales`;
    $('readySection').hidden = false;
    if (result.originalPages !== 2) {
      setNotice('Atención: el original tiene ' + result.originalPages + ' página(s), no 2. Se conservó todo el contenido: ' + result.totalSheets + ' hojas finales. Revisá el PDF antes de imprimir.', 'normal');
    } else {
      setNotice('Listo: 2 hojas A4 verticales idénticas. Cada hoja contiene las páginas 1 y 2 del test giradas 90°.', 'good');
    }
    if (autoLiniers && result.originalPages === 2 && !autoOpened) {
      autoOpened = true;
      await chrome.tabs.create({url:pdfOutputUrl});
    }
    $('readySection').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (error) {
    console.error('Error preparando impresión:', error);
    setNotice(error?.message || 'Ocurrió un error desconocido.', 'error');
  } finally {
    setBusy(false);
  }
}
async function prepareTab() {
  if (busy) return;
  if (!targetTabId) {
    setNotice('Abrí una página web, pulsá el icono de la extensión y elegí «Preparar pestaña actual».', 'error');
    return;
  }
  setBusy(true);
  let data;
  let sourceName = 'pagina-web';
  try {
    lastTab = await chrome.tabs.get(targetTabId);
    if (!lastTab?.url || (!/^https?:\/\//i.test(lastTab.url) && !(autoLiniers && lastTab.url === 'about:blank'))) {
      throw new Error('No se puede capturar esta pestaña. Probá con una página http(s) o cargá un PDF desde tu equipo.');
    }
    sourceName = lastTab.title || 'pagina-web';
    if (autoLiniers) {
      const checks = await chrome.scripting.executeScript({target:{tabId:targetTabId},func:(token) => ({
        valid: document.documentElement?.dataset.laindPrintToken === token && !!document.querySelector('.report-container') && /^Test del Dueño/i.test(document.title)
      }),args:[qs.get('token')]});
      if (!checks[0]?.result?.valid) throw new Error('La ventana original cambió. Abrí nuevamente Imprimir el Full-Test.');
    }
    const url = lastTab.url;
    const possiblyPdf = /\.pdf(?:$|[?#])/i.test(url) || /(?:pdf|download|archivo|documento)/i.test(url);
    if (possiblyPdf) {
      setNotice('Descargando el PDF desde la pestaña…');
      try { data = await readRemotePdf(url); }
      catch (e) { console.warn('No se pudo recuperar como PDF; se intentará capturar la página:', e); }
    }
    if (!data) {
      setNotice('Capturando la página con el motor de impresión de Edge…');
      try { data = await captureWebpageAsPdf(targetTabId); }
      catch (error) {
        // On browser-owned PDF tabs, the debugger is often unavailable. Try downloading directly.
        try { data = await readRemotePdf(url); }
        catch (ignored) { throw new Error('No fue posible capturar la pestaña: ' + (error.message || error) + '. Si es un PDF, guardalo y cargalo manualmente.'); }
      }
    }
  } catch (error) {
    setNotice(error.message || 'No se pudo leer la pestaña.', 'error');
    setBusy(false);
    return;
  }
  setBusy(false);
  await prepare(data, sourceName);
  if (autoLiniers) {
    try { await chrome.scripting.executeScript({target:{tabId:targetTabId},func:() => {
      document.documentElement.dataset.laindPrintState = 'done';
    }}); } catch (_) { /* Original tab was closed by the user. */ }
  }
}
async function prepareFile(file) {
  if (!file || busy) return;
  $('selectedFile').textContent = file.name + ' · ' + (file.size / (1024 * 1024)).toFixed(1) + ' MB';
  if (file.size > 70 * 1024 * 1024) {
    setNotice('El archivo supera el límite de 70 MB. Dividilo primero.', 'error');
    return;
  }
  try { await prepare(new Uint8Array(await file.arrayBuffer()), file.name); }
  catch (error) { setNotice(error.message || String(error), 'error'); }
}
$('captureButton').addEventListener('click', prepareTab);
$('pdfInput').addEventListener('change', (event) => prepareFile(event.target.files?.[0]));
const drop = $('dropZone');
for (const eventName of ['dragenter', 'dragover']) drop.addEventListener(eventName, event => { event.preventDefault(); drop.classList.add('is-dragging'); });
for (const eventName of ['dragleave', 'drop']) drop.addEventListener(eventName, event => { event.preventDefault(); drop.classList.remove('is-dragging'); });
drop.addEventListener('drop', (event) => {
  const file = event.dataTransfer.files?.[0];
  if (!file) return;
  if (!/\.pdf$/i.test(file.name) && file.type !== 'application/pdf') { setNotice('Solo se admiten archivos PDF.', 'error'); return; }
  prepareFile(file);
});
$('openPdfButton').addEventListener('click', () => {
  if (!pdfOutputUrl) return;
  // Opening a PDF in Edge's own viewer preserves the document's physical pages.
  // The browser's print dialog must use 1 copy and 1 page per sheet.
  const link = document.createElement('a');
  link.href = pdfOutputUrl;
  link.target = '_blank';
  link.rel = 'noopener';
  link.click();
});
$('downloadButton').addEventListener('click', async () => {
  if (!pdfOutputUrl) return;
  try { await chrome.downloads.download({ url: pdfOutputUrl, filename: pdfOutputName, saveAs: true }); }
  catch (error) { setNotice('No fue posible descargar el PDF: ' + error.message, 'error'); }
});
if (!globalThis.PDFLib?.PDFDocument) $('missingDependency').hidden = false;
(async () => {
  if (targetTabId) {
    try {
      lastTab = await chrome.tabs.get(targetTabId);
      $('tabDescription').textContent = lastTab.title || lastTab.url || 'Pestaña actual';
    } catch (error) { $('tabDescription').textContent = 'La pestaña original ya no está disponible'; }
  } else {
    $('tabDescription').textContent = 'Abrí el panel desde el botón de la extensión';
  }
  if (qs.get('auto') === '1' && targetTabId) prepareTab();
})();
window.addEventListener('beforeunload', () => {
  if (pdfOutputUrl) URL.revokeObjectURL(pdfOutputUrl);
});
