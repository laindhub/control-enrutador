import './vendor/pdf-lib.min.js';
import {imposeTwoUpTwice} from './imposition.mjs';
import {captureWebpageAsPdf,toBase64} from './capture.mjs';
const ORIGIN='https://liniers.xn--somosmasdueos-skb.com';
const jobs=new Map();
const armedByParent=new Map();
const recentChild=new Map();
const reportTabs=new Map();
chrome.tabs.onCreated.addListener(tab=>{
 if (!tab.openerTabId) return;
 recentChild.set(tab.openerTabId,{id:tab.id,at:Date.now()});
 const arm=armedByParent.get(tab.openerTabId);
 if (arm && Date.now()-arm.at<20000) reportTabs.set(arm.token,tab.id);
});
async function matchesReport(tabId,token){
 try{
  const result=await chrome.scripting.executeScript({target:{tabId},func:token=>document.documentElement?.dataset.laindPrintToken===token&&!!document.querySelector('.report-container')&&/^Test del Dueño/i.test(document.title),args:[token]});
  return !!result[0]?.result;
 }catch(_){return false;}
}
async function findReport(token,sender,reportDocument){
 const directId=reportDocument?sender.tab.id:reportTabs.get(token);
 if(directId && await matchesReport(directId,token))return directId;
 // Compatibility fallback if the browser supplies no openerTabId or the site's
 // popup flow changes. Never capture a document without checking its token.
 const tabs=await chrome.tabs.query({});
 const candidates=tabs.filter(t=>t.id===sender.tab.id||t.openerTabId===sender.tab.id||t.url==='about:blank'||t.url?.startsWith(ORIGIN+'/'));
 candidates.sort((a,b)=>Number(b.openerTabId===sender.tab.id)-Number(a.openerTabId===sender.tab.id));
 for(const tab of candidates){if(tab.id!==directId && await matchesReport(tab.id,token))return tab.id;}
 throw new Error('No se pudo identificar la ventana del test.');
}
async function prepare(token,sender,reportDocument){
 const tabId=await findReport(token,sender,reportDocument);
 const source=await captureWebpageAsPdf(tabId);
 const result=await imposeTwoUpTwice(source);
 const pdf=toBase64(result.bytes);
 if(pdf.length>8*1024*1024)throw new Error('Documento demasiado grande para impresión directa. Usá el panel manual.');
 const key=`print-job-${tabId}-${token}`;
 // Clean abandoned jobs. Session storage stays local and is not synced to an account.
 const previous=await chrome.storage.session.get(null);
 const expired=Object.keys(previous).filter(k=>k.startsWith('print-job-')&&Date.now()-(previous[k]?.created||0)>30*60*1000);
 if(expired.length)await chrome.storage.session.remove(expired);
 await chrome.storage.session.set({[key]:{pdf,originalPages:result.originalPages,sheetsPerCopy:result.sheetsPerCopy,totalSheets:result.totalSheets,tabId,created:Date.now()}});
 try{
  // Reuse the report tab: never create an automatic panel or PDF-viewer tab.
  await chrome.tabs.update(tabId,{url:chrome.runtime.getURL('direct.html')+'?job='+encodeURIComponent(key),active:true});
 }catch(error){await chrome.storage.session.remove(key);throw error;}
 return {ok:true};
}
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 if(!['prepare-liniers','arm-liniers'].includes(message?.type))return;
 if(!sender.tab?.id||sender.frameId!==0||sender.origin!==ORIGIN||typeof message.token!=='string'||!/^[a-zA-Z0-9-]{16,80}$/.test(message.token)){
  reply({ok:false,error:'Origen de impresión no válido.'});return;
 }
 const token=message.token;
 if(message.type==='arm-liniers'){
  const at=Number(message.at);
  if(!Number.isFinite(at)||Math.abs(Date.now()-at)>20000){reply({ok:false});return;}
  armedByParent.set(sender.tab.id,{token,at});
  const child=recentChild.get(sender.tab.id);
  if(child && child.at>=at-100 && child.at<=at+20000) reportTabs.set(token,child.id);
  // Bound auxiliary metadata; none of these maps contain report content.
  if(armedByParent.size>100)armedByParent.delete(armedByParent.keys().next().value);
  if(recentChild.size>100)recentChild.delete(recentChild.keys().next().value);
  if(reportTabs.size>100)reportTabs.delete(reportTabs.keys().next().value);
  reply({ok:true});return;
 }
 if(!jobs.has(token)){
  const task=prepare(token,sender,message.reportDocument===true);jobs.set(token,task);
  if(jobs.size>100)jobs.delete(jobs.keys().next().value);
  task.catch(()=>jobs.delete(token));
 }
 jobs.get(token).then(reply,e=>reply({ok:false,error:e.message}));return true;
});
chrome.tabs.onRemoved.addListener(async tabId=>{
 armedByParent.delete(tabId);recentChild.delete(tabId);
 for(const [token,id]of reportTabs)if(id===tabId)reportTabs.delete(token);
 const data=await chrome.storage.session.get(null);
 const keys=Object.keys(data).filter(k=>k.startsWith(`print-job-${tabId}-`));
 if(keys.length)await chrome.storage.session.remove(keys);
});
chrome.commands.onCommand.addListener(async command=>{
 if(command!=='preparar-impresion')return;
 const [tab]=await chrome.tabs.query({active:true,currentWindow:true});const p=new URLSearchParams();
 if(tab?.id&&!tab.url?.startsWith('chrome-extension://')){p.set('tab',String(tab.id));p.set('auto','1');}
 await chrome.tabs.create({url:chrome.runtime.getURL('panel.html')+(p.size?'?'+p:'')});
});
