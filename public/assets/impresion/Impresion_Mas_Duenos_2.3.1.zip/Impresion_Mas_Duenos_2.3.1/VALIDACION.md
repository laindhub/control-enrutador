# Validación 2.3.1

## Resultado local
- Se mantienen sin cambios los cálculos de giro, posición y escala de imposition.mjs de 2.1.0, ya comprobados con las páginas reales proporcionadas por el usuario.
- Prueba DOM del service worker modular real y direct.mjs con APIs de navegador simuladas: 2 páginas originales → 0 pestañas creadas, 1 pestaña reutilizada, 1 llamada a window.print y cierre tras afterprint.
- Duplicar la notificación del mismo trabajo no repite captura, navegación ni impresión.
- Original de 3 páginas: se conservan las cuatro hojas finales; aparece aviso y se espera la revisión antes de imprimir.
- Fallo de captura: no navega, no imprime y libera el depurador.
- Se eliminan tanto los datos temporales de sesión como la hoja CSS temporal usada durante la captura.
- PDF.js incluido en el paquete renderizó realmente el PDF compuesto de prueba a 300 dpi, usando un motor canvas en Node. Se inspeccionó visualmente la imagen.
- Renderizar una hoja y reutilizarla para ambas copias produjo dos superficies idénticas sin repetir el renderizado. El renderizado de esa muestra tomó aproximadamente 0,4 s en este entorno; no es una medición del flujo completo ni una garantía de tiempo en otro equipo.
- Se incluyó la variante legacy de PDF.js para disponer de sus adaptaciones de compatibilidad.
- Sintaxis JavaScript y presencia de recursos del manifest verificadas.

## Límite
No se inició Chromium ni se probó aquí el diálogo nativo. Sus APIs y los eventos print/afterprint se simularon en la prueba DOM. La prueba real de PDF.js verifica el renderizado, no el diálogo ni la paginación del navegador. Debe comprobarse en el navegador del usuario que el diálogo se abre, contiene dos A4 y que la pestaña se cierra al confirmar o cancelar.

No se confirmó una impresión física. No se modificaron registros del sitio.

Versión 2.2.1: cambio de nombre visible a Impresion Mas Dueños en manifest, panel, popup, título de impresión y metadatos PDF. Sin cambios en el flujo o la composición de 2.2.0.

## Pruebas añadidas en 2.3.0
- Clic real de DOM sobre el icono dentro del botón: se reconoce, se avisa al worker y se mantiene la ejecución única del controlador del sitio. No se cancela ni reproduce el clic.
- El token del clic sobrevive a document.open/write y llega al reporte.
- Un botón ajeno no arma una impresión.
- Worker y controlador de impresión en sandbox: 0 llamadas a tabs.query en la ruta de clic asociada, 0 pestañas nuevas, 1 navegación de la pestaña del reporte y 1 llamada a print para el test de 2 páginas.
- La página directa no contiene botones.
- Original de 3 páginas: conserva el contenido y muestra aviso con Ctrl+P.
- Error de captura: no imprime y libera el depurador.
Estas pruebas usan DOM y APIs del navegador simuladas; la prueba final del diálogo nativo sigue correspondiendo al navegador del usuario.

## Indicador 2.3.1
Se añade al botón un único indicador verde animado, sin texto adicional ni manejadores de clic propios. Respeta prefers-reduced-motion. La composición PDF y el controlador de impresión no cambian respecto de 2.3.0.
