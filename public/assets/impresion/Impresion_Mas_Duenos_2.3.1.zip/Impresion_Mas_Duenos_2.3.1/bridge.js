(() => {
  'use strict';
  const seen = new Set();
  const ORIGIN = 'https://liniers.xn--somosmasdueos-skb.com';
  function notify(token) {
    if (typeof token !== 'string' || !/^[a-zA-Z0-9-]{16,80}$/.test(token) || seen.has(token)) return;
    seen.add(token);
    chrome.runtime.sendMessage({type: 'prepare-liniers', token, reportDocument: !!document.querySelector('.report-container')}).then(response => {
      if (!response?.ok) throw new Error(response?.error || 'No se pudo abrir la preparación.');
    }).catch(error => {
      seen.delete(token);
      showError(error.message);
    });
  }
  function showError(message) {
    if (!document.body || document.getElementById('laind-print-error')) return;
    const box = document.createElement('div');
    box.id = 'laind-print-error';
    box.style.cssText = 'position:fixed;bottom:16px;left:16px;right:16px;padding:16px;background:#fff3d6;color:#222;z-index:2147483647;font:15px Arial;border:2px solid #c88b00';
    box.textContent = 'Impresion Mas Dueños: ' + message + ' Abrí la ventana del test y usá el icono de la extensión → Preparar pestaña actual. No se imprimió nada.';
    document.body.append(box);
  }
  const badgeSelector = '.laind-extension-active-badge';
  const buttonPattern = /^Imprimir\s+(?:el\s+)?Full[-\s]?Test$/i;
  let badgeFramePending = false;
  function markPrintButtons() {
    const buttons = [...document.querySelectorAll('button')].filter(b => buttonPattern.test(b.textContent.trim()));
    if (!buttons.length) return;
    if (!document.getElementById('laind-extension-active-style')) {
      const style = document.createElement('style');
      style.id = 'laind-extension-active-style';
      style.textContent = `
        .laind-extension-active-badge { display:inline-block!important; flex:0 0 12px!important; width:12px!important; height:12px!important; border-radius:50%!important; background:#22c55e!important; box-shadow:0 0 0 3px rgba(34,197,94,.14); vertical-align:middle; pointer-events:none; animation:laind-extension-heartbeat 1.6s ease-in-out infinite; }
        @keyframes laind-extension-heartbeat { 0%,35%,100% {transform:scale(1);box-shadow:0 0 0 3px rgba(34,197,94,.14)} 12% {transform:scale(1.2);box-shadow:0 0 0 6px rgba(34,197,94,.05)} 23% {transform:scale(1)} 29% {transform:scale(1.12)} }
        @media(prefers-reduced-motion:reduce){.laind-extension-active-badge{animation:none!important}}
        @media print{.laind-extension-active-badge{display:none!important}}
      `;
      (document.head || document.documentElement).append(style);
    }
    for (const button of buttons) {
      if (button.querySelector(badgeSelector)) continue;
      const dot = document.createElement('span');
      dot.className = 'laind-extension-active-badge';
      dot.setAttribute('role','img');
      dot.setAttribute('aria-label','Impresion Mas Dueños activa');
      dot.title = 'Impresion Mas Dueños activa';
      button.append(dot);
    }
  }
  function scheduleBadges() {
    if (badgeFramePending) return;
    badgeFramePending = true;
    requestAnimationFrame(() => {badgeFramePending = false; markPrintButtons();});
  }
  scheduleBadges();
  document.addEventListener('click', event => {
    const button = event.target?.closest?.('button');
    if (!button || button.disabled || !/^Imprimir\s+(?:el\s+)?Full[-\s]?Test$/i.test(button.textContent.trim())) return;
    const arm = () => {
      const token = button.dataset.laindClickToken;
      if (!token) return;
      chrome.runtime.sendMessage({type:'arm-liniers', token, at:Number(button.dataset.laindClickAt)}).catch(()=>{});
    };
    // Also tolerate reverse listener ordering between isolated and main worlds.
    if (button.dataset.laindClickToken) arm(); else queueMicrotask(arm);
  }, true);
  window.addEventListener('message', event => {
    if (event.source !== window || event.origin !== ORIGIN || event.data?.type !== 'LAIND_REPORT_PRINT_V2') return;
    notify(event.data.token);
  });
  // document.write can replace the document before the isolated listener is ready.
  // The marker and the relay from the original window cover that transition.
  const observer = new MutationObserver(() => {
    scheduleBadges();
    const doc = document.documentElement;
    if (doc?.dataset.laindPrintState === 'pending') notify(doc.dataset.laindPrintToken);
  });
  observer.observe(document, {childList:true,subtree:true,attributes:true,attributeFilter:['data-laind-print-token','data-laind-print-state']});
})();
