/**
 * Two-up imposition for A4 portrait sheets, repeating the entire set twice.
 * Uses a local copy of pdf-lib (window.PDFLib, MIT License).
 * Source files never leave the browser during PDF imposition.
 */
export const SETTINGS = Object.freeze({
  copies: 2,
  pagesPerSheet: 2,
  sheet: 'A4',
  orientation: 'vertical',
  paperWidth: 595.28,
  paperHeight: 841.89,
  margin: 0.0,
  gutter: 0.0
});

export async function imposeTwoUpTwice(sourceData, onProgress = () => {}) {
  if (!globalThis.PDFLib?.PDFDocument) {
    throw new Error('Falta pdf-lib. Volvé a extraer el paquete completo de la extensión.');
  }
  const { PDFDocument, degrees } = globalThis.PDFLib;
  let input;
  try {
    input = await PDFDocument.load(sourceData, { updateMetadata: false });
  } catch (error) {
    throw new Error('No fue posible leer el PDF. Si tiene contraseña, desbloquealo primero. Detalle: ' + (error.message || error));
  }
  const sourcePages = input.getPages();
  if (!sourcePages.length) throw new Error('El documento no contiene páginas.');
  const output = await PDFDocument.create();
  output.setTitle('Impresion Mas Dueños · 2 páginas por hoja · 2 copias');
  output.setCreator('Impresion Mas Dueños para Microsoft Edge');
  output.setSubject('A4 vertical · 2 páginas originales por hoja · 2 copias completas');

  // Embedded vector pages preserve quality (including text/vector artwork).
  onProgress('Incorporando ' + sourcePages.length + ' páginas…');
  const embedded = await output.embedPages(sourcePages);
  const { paperWidth: W, paperHeight: H, margin, gutter } = SETTINGS;
  const slotHeight = (H - 2 * margin - gutter) / 2;
  const slotWidth = W - 2 * margin;
  const totalSheetsPerCopy = Math.ceil(sourcePages.length / 2);

  for (let copy = 0; copy < 2; copy++) {
    for (let sheetIndex = 0; sheetIndex < totalSheetsPerCopy; sheetIndex++) {
      const paper = output.addPage([W, H]);
      for (let slotIndex = 0; slotIndex < 2; slotIndex++) {
        const sourceIndex = sheetIndex * 2 + slotIndex;
        if (sourceIndex >= embedded.length) continue;
        const page = embedded[sourceIndex];
        const rawRotation = sourcePages[sourceIndex].getRotation().angle;
        // Match Chromium two-up on portrait A4: rotate content 90 degrees CCW.
        // Compensate the source /Rotate first (clockwise in PDF).
        const angle = (((90 - rawRotation) % 360) + 360) % 360;
        const horizontal = angle === 90 || angle === 270;
        const effectiveWidth = horizontal ? page.height : page.width;
        const effectiveHeight = horizontal ? page.width : page.height;
        const scale = Math.min(slotWidth / effectiveWidth, slotHeight / effectiveHeight);
        const desiredWidth = effectiveWidth * scale;
        const desiredHeight = effectiveHeight * scale;
        // Page 1 below and page 2 above: when the sheet is turned clockwise,
        // the reading order becomes left-to-right, as in the supplied reference.
        const slotBottom = slotIndex === 0 ? margin : margin + slotHeight + gutter;
        const left = margin + (slotWidth - desiredWidth) / 2;
        const bottom = slotBottom + (slotHeight - desiredHeight) / 2;
        let x = left;
        let y = bottom;
        if (angle === 90) x += desiredWidth;
        if (angle === 180) { x += desiredWidth; y += desiredHeight; }
        if (angle === 270) y += desiredHeight;
        paper.drawPage(page, {
          x, y,
          width: page.width * scale,
          height: page.height * scale,
          rotate: degrees(angle)
        });
      }
      onProgress('Preparando hoja ' + (copy * totalSheetsPerCopy + sheetIndex + 1) + ' de ' + (2 * totalSheetsPerCopy) + '…');
      // Keep the extension UI responsive with large documents.
      if ((sheetIndex % 8) === 7) await new Promise(resolve => setTimeout(resolve, 0));
    }
  }
  const bytes = await output.save({ useObjectStreams: true });
  return {
    bytes,
    originalPages: sourcePages.length,
    totalSheets: totalSheetsPerCopy * 2,
    sheetsPerCopy: totalSheetsPerCopy
  };
}
