export function fromBase64(base64) {
 const raw=atob(base64);const out=new Uint8Array(raw.length);
 for(let i=0;i<raw.length;i++)out[i]=raw.charCodeAt(i);
 return out;
}
export function toBase64(bytes) {
 const chunks=[];for(let i=0;i<bytes.length;i+=32768)chunks.push(String.fromCharCode(...bytes.subarray(i,i+32768)));
 return btoa(chunks.join(''));
}
const toByteArray=fromBase64;
export async function captureWebpageAsPdf(tabId) {
  const target = { tabId };
  let attached = false;
  const layoutStyleId = 'laind-print-layout-' + crypto.randomUUID();
  let layoutStyleAdded = false;
  try {
    await chrome.debugger.attach(target, '1.3');
    attached = true;
    const adjusted = await chrome.scripting.executeScript({target,func:(id) => {
      if (!document.querySelector('.report-container')) return false;
      const style = document.createElement('style');
      style.id = id;
      style.textContent = '@media print { .report-container .section-title { break-after: avoid-page !important; page-break-after: avoid !important; } }';
      document.head.append(style);
      return true;
    },args:[layoutStyleId]});
    layoutStyleAdded = !!adjusted[0]?.result;
    const result = await chrome.debugger.sendCommand(target, 'Page.printToPDF', {
      landscape: false,
      displayHeaderFooter: false,
      printBackground: true,
      preferCSSPageSize: false,
      paperWidth: 8.2677,
      paperHeight: 11.6929,
      marginTop: 0.25,
      marginBottom: 0.25,
      marginLeft: 0.25,
      marginRight: 0.25,
      transferMode: 'ReturnAsBase64'
    });
    if (!result?.data) throw new Error('Edge no devolvió un documento.');
    return toByteArray(result.data);
  } finally {
    if (layoutStyleAdded) {
      try { await chrome.scripting.executeScript({target,func:(id) => document.getElementById(id)?.remove(),args:[layoutStyleId]}); } catch (_) { /* tab closed */ }
    }
    if (attached) {
      try { await chrome.debugger.detach(target); } catch (ignored) { /* already detached */ }
    }
  }
}
