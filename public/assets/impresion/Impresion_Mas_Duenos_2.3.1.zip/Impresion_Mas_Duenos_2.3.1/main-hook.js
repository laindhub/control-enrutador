/* Runs before the site's code. Never submits forms or changes visit data. */
(() => {
  'use strict';
  const KEY = '__laindTwoUpV2';
  const EVENT = 'LAIND_REPORT_PRINT_V2';
  const ORIGIN = 'https://liniers.xn--somosmasdueos-skb.com';
  function install(win, relay, openingToken = null) {
    try {
      if (win[KEY]) return;
      win[KEY] = true;
      let armedToken = null;
      win.document.addEventListener('click', event => {
        const button = event.target?.closest?.('button');
        if (!button || button.disabled || !/^Imprimir\s+(?:el\s+)?Full[-\s]?Test$/i.test(button.textContent.trim())) return;
        const token = crypto.randomUUID();
        const at = Date.now();
        armedToken = {token, at};
        button.dataset.laindClickToken = token;
        button.dataset.laindClickAt = String(at);
        // Do not cancel or replay the site's click; preserve popup user activation.
      }, true);
      const nativePrint = win.print.bind(win);
      const nativeClose = win.close.bind(win);
      win.print = function () {
        // Only the known report is intercepted; ordinary website printing passes through.
        if (!win.document.querySelector('.report-container') ||
            !/^Test del Dueño/i.test(win.document.title)) return nativePrint();
        const doc = win.document.documentElement;
        let token = doc.dataset.laindPrintToken;
        if (!token || doc.dataset.laindPrintState === 'done') token = doc.dataset.laindPrintToken = (doc.dataset.laindPrintState !== 'done' && openingToken) || crypto.randomUUID();
        if (doc.dataset.laindPrintState === 'pending') return;
        doc.dataset.laindPrintState = 'pending';
        win.postMessage({type: EVENT, token}, ORIGIN);
        if (relay && relay !== win) relay.postMessage({type: EVENT, token}, ORIGIN);
        // The extension captures this exact document, not the visit's detail page.
      };
      win.close = function () {
        if (win.document.documentElement?.dataset.laindPrintState === 'pending') {
          win.document.documentElement.dataset.laindCloseRequested = '1';
          return;
        }
        return nativeClose();
      };
      const nativeOpen = win.open;
      win.open = function (...args) {
        const child = Reflect.apply(nativeOpen, win, args);
        const request = armedToken && Date.now() - armedToken.at < 20000 ? armedToken : null;
        armedToken = null;
        if (child) { try { install(child, win, request?.token || null); } catch (_) { /* cross-origin window */ } }
        return child;
      };
    } catch (_) { /* Leave unsupported windows unchanged. */ }
  }
  install(window, null);
})();
