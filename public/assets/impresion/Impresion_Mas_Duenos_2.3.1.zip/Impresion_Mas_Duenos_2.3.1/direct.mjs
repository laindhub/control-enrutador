import {getDocument,GlobalWorkerOptions} from './vendor/pdf.min.mjs';
import {fromBase64} from './capture.mjs';
import {renderSheets} from './direct-render.mjs';
const $=id=>document.getElementById(id);
const key=new URLSearchParams(location.search).get('job');
let printStarted=false;
GlobalWorkerOptions.workerSrc=chrome.runtime.getURL('vendor/pdf.worker.min.mjs');
async function close(){const tab=await chrome.tabs.getCurrent();await chrome.tabs.remove(tab.id);}
window.addEventListener('beforeprint',()=>{printStarted=true;});
window.addEventListener('afterprint',()=>{if(printStarted)close().catch(()=>{});});
(async()=>{
 try{
  if(!key?.startsWith('print-job-'))throw new Error('No se encontró el trabajo de impresión.');
  const job=(await chrome.storage.session.get(key))[key];const tab=await chrome.tabs.getCurrent();
  if(!job||job.tabId!==tab.id)throw new Error('El trabajo ya no está disponible. Volvé a imprimir desde Liniers.');
  const pdf=await getDocument({data:fromBase64(job.pdf),isEvalSupported:false,useWasm:false,useSystemFonts:true}).promise;
  if(pdf.numPages!==job.totalSheets)throw new Error('El número de hojas no coincide con el trabajo preparado.');
  await renderSheets(pdf,job,{document,container:$('sheets'),onProgress:()=>{}});
  await pdf.destroy();await chrome.storage.session.remove(key);
  if(job.originalPages!==2){$('status').textContent=`El test tiene ${job.originalPages} páginas y genera ${job.totalSheets} hojas. Usá Ctrl+P si querés imprimirlo o cerrá esta pestaña.`;return;}
  $('status').textContent='Abriendo impresión…';
  await new Promise(resolve=>requestAnimationFrame(resolve));
  printStarted=true;window.focus();window.print();
 }catch(error){$('status').textContent='No se pudo preparar la impresión: '+error.message;}
})();
