# Impresion Mas Dueños - v2.3.1

## Actualizar
1. Extraé el ZIP completo en una carpeta fija.
2. Desactivá la versión anterior y la extensión de diagnóstico en edge://extensions (o la pantalla de extensiones de tu navegador Chromium).
3. Cargar desempaquetada → seleccioná Impresion_Mas_Duenos_2.3.1, donde está manifest.json.
4. Recargá la pestaña de Liniers para instalar la intervención nueva.

Incluye las bibliotecas necesarias. No hay que ejecutar un CMD ni descargar componentes.

## Uso directo
En Liniers, pulsá Imprimir el Full-Test como siempre.
- Captura el reporte y prepara la misma composición de la versión 2.1.0.
- Reutiliza la pestaña del reporte: no abre un panel ni otra pestaña de PDF.
- Abre automáticamente el diálogo de impresión para los tests de dos páginas.
- Después de confirmar o cancelar, cierra la pestaña temporal y volvés a Liniers.

Solo queda confirmar la impresión final. La extensión no envía papel a la impresora sin esa confirmación.

En el diálogo usá A4 vertical, 1 copia, 1 página por hoja y una cara (sin doble faz). Las dos hojas idénticas ya están incorporadas al documento. Mantené desactivados los encabezados y pies del navegador para no agregar información a las hojas.

Si el original tiene una cantidad de páginas diferente de 2, la pestaña muestra un aviso con las hojas totales. Ctrl+P permite imprimir tras revisar. Se conserva todo el contenido.

## Calidad y tiempo
La composición sigue siendo un PDF vectorial. Para abrir directamente el diálogo, se prepara una superficie de impresión con imágenes PNG de 300 dpi, sin compresión con pérdida. Las dos copias reutilizan la misma imagen: no se renderiza dos veces. La impresión directa deja de ser texto seleccionable; El panel manual, accesible desde el icono, conserva la posibilidad de guardar el PDF vectorial.
El tiempo total depende de la captura y de tu equipo. No se promete una cantidad fija de segundos.

## Recuperación
Si el navegador bloquea la apertura automática, usá Ctrl+P. La pantalla temporal no muestra botones de Imprimir, Guardar ni Cerrar.
Si falla la captura, se muestra un error en Liniers. DevTools debe estar desconectado del reporte para que la extensión pueda usar el depurador.
El icono de la extensión conserva el panel manual para cargar un PDF o capturar una pestaña a pedido. Ese panel no se abre durante el flujo normal de Liniers.

## Privacidad
No envía documentos a servicios externos. Usa chrome.storage.session temporalmente, en memoria y sin sincronización, para pasar el PDF a la misma pestaña. El trabajo se elimina al cargarlo o cerrar la pestaña. Se purgan trabajos abandonados de más de 30 minutos al preparar otro test; al reiniciar, recargar o desactivar la extensión, el navegador borra este almacenamiento.
El ZIP no incluye PDFs, datos de leads ni credenciales.

## Optimización 2.3.0
Se detecta el clic sobre Imprimir el Full-Test (incluido su icono) sin cancelarlo ni repetirlo. Se avisa al worker y se asocia la ventana nueva con ese clic. Se valida su token y se captura directamente, sin buscar en las demás pestañas en la ruta normal. Si el navegador no proporciona el vínculo entre ventanas, se mantiene la búsqueda anterior como respaldo. El reporte todavía debe ser generado por el sitio: detectarlo antes no elimina ese tiempo.
La pantalla temporal solo muestra Preparando/Abriendo impresión. Las hojas están ocultas fuera del diálogo nativo y se cierra la pestaña al confirmar o cancelar.

## Indicador de extensión activa
Al reconocer Imprimir el Full-Test, añade un círculo verde con latido suave junto al texto. Indica que la extensión está activa y reconoce el botón; no significa que la impresora esté conectada ni que el trabajo haya terminado. Se añade también si la página crea o reemplaza el botón dinámicamente. Respeta la preferencia del sistema de reducir movimiento y no aparece en la impresión.
